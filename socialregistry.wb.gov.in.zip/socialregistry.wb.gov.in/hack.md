# Security Assessment Report: socialregistry.wb.gov.in

**Target:** Family Level Data Collection Form — Government of West Bengal / NIC
**URL:** https://socialregistry.wb.gov.in
**Stack:** Laravel + Livewire + Alpine.js + MySQL (inferred)
**Assessment Date:** June 2026

---

## 1. CRITICAL: Static / Reusable CSRF Token

**Location:** Every HTML page (login.html, admin.html, forget-password.html, all policy pages)
**Token Value:** `R8ckLrrRswlV6lqdF3ojQjk4n6tVYsPLh5iMddUN`

The **same CSRF token** is hardcoded into every page's source. This means:
- Token does not rotate per session or per request
- An attacker can extract the token from the public HTML and craft forged requests
- CSRF protection is effectively **non-functional**
- Enables Cross-Site Request Forgery (CSRF) against all POST endpoints

**Endpoints affected:**
- `POST /admin/loginPost` — Login form
- `POST /admin/forgetpasswordPost` — Forgot password
- `POST /admin/livewire/update` — Livewire component updates

**Exploit Scenario:**
1. Attacker extracts token from any page source
2. Crafts a phishing page that submits a forged POST to loginPost
3. Bypasses CSRF protection entirely

**Fix:** Generate fresh CSRF token per session via `csrf_token()`.

---

## 2. Weak Math CAPTCHA — Easily Automatable

**Location:** Login and Forgot Password forms
**Type:** Simple 2-digit math problem
**CAPTCHA Endpoint:** `GET /admin/refresh-captcha` (returns raw HTML)

### Weaknesses:
- **maxlength="2"** — only 2 characters, extremely low entropy
- **Client-side validation only** — the JS constraint `[^0-9]` is trivially bypassed
- **CAPTCHA is purely numeric math** — solver can be written in < 10 lines of OCR or bypassed via predictable image patterns
- **Refresh endpoint returns captcha HTML directly** — `GET /admin/refresh-captcha` can be abused to generate unlimited captchas
- **No rate limiting observed on captcha refresh** — enables automated brute-force

**Exploit:** Automate solving with OCR (Tesseract) or simple image processing on the math captcha images. Since it's 2-digit math, the search space is ~100 combinations.

---

## 3. Information Disclosure via Source Code

**Location:** All HTML pages

### Exposed in source:
- Full server-side endpoint paths (`/admin/loginPost`, `/admin/livewire/update`, `/admin/forgetpasswordPost`, `/admin/refresh-captcha`)
- Livewire version (`livewire.min.js@id=a60c5ee6`)
- CSRF token (see #1)
- Technology stack: Laravel, Livewire, Alpine.js, Tailwind CSS, Chart.js, jQuery, SortableJS, Highcharts, Flatpickr, Axios
- Asset base URL: `https://socialregistry.wb.gov.in/admin/`
- Template author: Webonzer (commercial admin template vendor)
- PWA manifest references, theme color

**Risk:** Enables fingerprinting for known CVEs in specific library versions.

---

## 4. OTP-Based Authentication — Potential Weaknesses

**Login flow:** Mobile No + Password + CAPTCHA → "Send OTP" → OTP verification

### Concerns:
- **No rate limiting visible** — mobile number field could be enumerated to check if registered
- **OTP length** — unknown (not visible in front-end code), but short OTPs (4-6 digits) are brute-forceable if no rate limit
- **Forgot Password** (`/admin/forgetpasswordPost`) requires ONLY mobile number + captcha — weaker authentication than login
- **Password field** has `autocomplete="off"` but toggle visibility via SVG icon (minor info leak shoulder-surfing)

---

## 5. Missing Security Headers (Inferred)

**Check:** No `Content-Security-Policy`, `X-Frame-Options`, or `Strict-Transport-Security` visible in the HTML.

**If missing server-side:**
- Clickjacking attacks possible (missing `X-Frame-Options: DENY` or `frame-ancestors`)
- XSS protection headers likely absent
- No CSP means inline scripts (Alpine.js `x-data`, event handlers) could allow stored XSS

---

## 6. No Bug Bounty / Security Disclosure Policy

**Check:** `/.well-known/security.txt` → 404
**Check:** No security contact information on the site

**Impact:** Security researchers have no formal channel to report vulnerabilities. This means bugs go unreported.

---

## 7. Livewire Endpoint Exposure

**Endpoint:** `POST /admin/livewire/update`
**Response to GET:** 405 Method Not Allowed (endpoint exists)

Livewire exposes component method calls directly. Potential vulnerabilities:
- **Mass assignment** — if Livewire components don't properly guard `$fillable` properties
- **Method invocation** — arbitrary public component methods could be called
- **Parameter tampering** — attackers could manipulate component state

**Recon needed:** Identify all Livewire component class names by searching the JavaScript for `wire:model` and `wire:click` bindings.

---

## 8. Directory / Endpoint Discovery

### Confirmed accessible:
| Endpoint | Method | Status |
|---|---|---|
| `/` | GET | 200 — Portal home |
| `/admin` | GET | 200 — Officer login |
| `/admin/login.html` | GET | 200 — Login page |
| `/admin/forget-password.html` | GET | 200 — Forgot password |
| `/admin/legal-disclaimer.html` | GET | 200 |
| `/admin/privacy-policy.html` | GET | 200 |
| `/admin/copyright-policy.html` | GET | 200 |
| `/admin/hyperlink-policy.html` | GET | 200 |
| `/admin/terms-and-conditions.html` | GET | 200 |
| `/admin/refresh-captcha` | GET | 200 — CAPTCHA image |
| `/admin/livewire/update` | POST | 405 (exists) |
| `/admin/loginPost` | POST | Endpoint exists |
| `/admin/forgetpasswordPost` | POST | Endpoint exists |
| `/admin/build/assets/app-D56DFE7e.js` | GET | 200 — JS bundle |

### Not accessible (good — patched or not present):
| Endpoint | Status |
|---|---|
| `/.git/config` | 404 |
| `/.env` | 404 |
| `/storage/logs/laravel.log` | 404 |
| `/_debugbar` | 404 |
| `/phpinfo.php` | 404 |
| `/robots.txt` | 404 |
| `/sitemap.xml` | 404 |

---

## 9. Additional Observations

- **Home icon link** on login page uses relative path `../admin.html` which resolves correctly — but this confirms the file structure is predictable
- **Script nonces or integrity hashes** are NOT used on any external CDN scripts (jQuery, Bootstrap, FontAwesome) — potential supply chain risk if CDN is compromised
- **Version disclosure:** Bootstrap 5.3.3, jQuery 3.7.1, FontAwesome 6.6.0 explicitly loaded via CDN
- **Template author disclosure:** "Webonzer" — a known commercial admin template vendor. The template metadata says "Premium Tailwind CSS Admin & Dashboard Template"

---

## 10. Recommended Testing Vectors (For Authorized Testing Only)

If you are an **authorized** tester, these are the next steps:

1. **Brute-force CAPTCHA** — Automate math captcha solving, then brute-force OTP on login
2. **Livewire parameter tampering** — Intercept `POST /admin/livewire/update` requests and modify component state
3. **SQL Injection** — Test `mobile_no`, `password`, and `captcha` parameters on POST endpoints
4. **IDOR (Insecure Direct Object Reference)** — Check if user/family data can be accessed by changing IDs after authentication
5. **Rate limiting tests** — Check if login/OTP/forgot-password endpoints have rate limits
6. **Session fixation** — Check if session tokens are regenerated after login
7. **JWT / Token analysis** — If JWT used after OTP, check algorithm confusion, expiration
8. **Mass assignment** — Try injecting extra fields into Livewire component updates

---

## Classification Summary

| Severity | Issue | Count |
|---|---|---|
| **Critical** | Static CSRF token across all pages | 1 |
| **High** | Weak captcha — easily automatable | 1 |
| **Medium** | Information disclosure in source | 1 |
| **Medium** | OTP flow lacks visible rate limiting | 1 |
| **Low** | Missing security headers (inferred) | 1 |
| **Low** | No security.txt / disclosure policy | 1 |
| **Info** | Technology stack fingerprinting | 1 |

---

*Report generated by automated source code analysis and endpoint probing. For responsible disclosure, contact NIC at https://www.nic.in/ or report to cert-in.org.in.*
